package com.example.cs124h_dining_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ExpandableListAdapter
import android.widget.ExpandableListView
import android.widget.TextView
import androidx.appcompat.view.menu.ExpandedMenuView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import com.example.cs124h_dining_app.adapters.MenuAdapter
import com.example.cs124h_dining_app.data.source.DiningMenuDataSource
import com.example.cs124h_dining_app.data.DiningMenuRepository
import com.example.cs124h_dining_app.models.MenuRequest
import com.example.cs124h_dining_app.models.MenuItem

class MainActivity : AppCompatActivity() {
    private val adapter = MenuAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val menu: ExpandableListView = findViewById(R.id.menuInfo)
        val menuRepo = DiningMenuRepository(DiningMenuDataSource)
        val data = menuRepo.getData(MenuRequest("3", "2023-11-27"))["Dinner"]
            ?: throw Exception("Failed to fetch menu data")
        adapter.cafeList = data.keys.toList()
        adapter.cafeMenus = data
        menu.setAdapter(adapter)
    }
}