package com.example.israpp2;

import android.content.Context;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class toJSON {
   private final Context context;

    public toJSON (Context context) {
        this.context = context;
    }

    public Context getContext() {
        return context;
    }

    public void jsonFiler (EnterData input) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(input);
            System.out.println(json);

            // Assuming 'context' is an instance of Context (like an Activity)

            File file = new File(context.getFilesDir(), "JSONData");
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(json);
            fileWriter.flush();
            fileWriter.close();

            System.out.println("Saved to JSONData");

        } catch (IOException e) {
            System.out.println("Failed to save");
            throw new RuntimeException(e);
        }
    }
}
