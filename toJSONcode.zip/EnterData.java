package com.example.israpp2;

import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.SeekBar;

import androidx.annotation.NonNull;

public class EnterData {
    private final String time;

    private final String response;
    private final String rating;

    public EnterData(EditText setResponse, SeekBar setTime, RatingBar setRating) {
        if (setTime == null || setRating == null || setResponse == null) {
            throw new IllegalArgumentException();
        }
        response = setResponse.getText().toString();
        time = Integer.toString(setTime.getProgress());
        rating = Integer.toString(setRating.getNumStars());
    }

    public String getTime() {
        return time;
    }

    public String getResponse() {
        return response;
    }

    public String getRating() {
        return rating;
    }

    @NonNull
    @Override
    public String toString() {
        return "time: " + time + " response: " + response + " rating: " + rating;
    }
}
