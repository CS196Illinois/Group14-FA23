Plan file. Can also be a PDF or something else. Just make sure to name PLAN with all caps
